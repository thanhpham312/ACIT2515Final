import json

class User():
    def __init__(self, id, username):
        self.__id = id
        self.__username = username
