This is a prototype of the final product.

Upon running "atm_simulator.py", user will be greeted with a  menue screen without having to go through pin verification.

The only thing that's working is switching between the main menu and the following screens:
    QUICK CASH
    DEPOSIT
    CHECK BALANCE

Users can't currently switch back once getting to one of the above menus.

The exit button will exit the program completely.